<!DOCTYPE html>
<html>
<head>
<style>
.alert {

    padding: 20px;
    background-color: #2196F3;;
    color: white;
}
.alert.success {background-color: #4CAF50;}
.alert.info {background-color: #2196F3;}
.alert.warning {background-color: #ff9800;}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
</style>
    </head>

<?php
$servername="208.91.198.170";
$username="tourlwg2_root";
$password="g2]3T2ZAw8";
$database="tourlwg2_tour";
$con=mysqli_connect($servername,$username,$password,$database);
if(isset($_COOKIE["uid"])){
	session_id("log");
	session_start();
}
else {
	header('Location: login.php');
}

if(isset($_COOKIE["uid"]))
{   $name=$_COOKIE['uid'];
			session_write_close();
			$avid= $_POST["request"];
			
			session_id("prof");
			session_start();
			 $gui=$_COOKIE['idd'];
			 $today = date("Y-m-d")+time();
			 $msg= " has requested you for his tour. Press [Confirm] to book and  [cancel] to dismiss";
			
			$sql="INSERT INTO messages
            ( Name, Message, guideId, time, id, status )
			VALUES( '$name', '$msg','$gui','$today', '$avid', '0')";
			mysqli_query($con, $sql);
			?>
			
			<body>
			
			<div class="alert success">
  <span class="closebtn">&times;</span>  
  <strong>Good going! </strong> You Have requested for a booking. <a href="prof2.php" >Go back</a>
</div>
			</body>
		<?php }
		else 
		{?>
  
    <body>
   <div class="alert">
  <span class="closebtn">&times;</span>  
  <strong>Sorry!</strong> Not Logged in. <a href="login.php" >Log in</a>
</div>
    </body>
    </html>
    
		<?php }
	
?>
