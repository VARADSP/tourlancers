<!DOCTYPE html>

<?php
$er=false;
$servername="208.91.198.170";
$username="tourlwg2_root";
$password="g2]3T2ZAw8";
$database="tourlwg2_tour";
$con=mysqli_connect($servername,$username,$password,$database);
if($_SERVER['REQUEST_METHOD']=='POST')
{
	if(isset($_POST['login']))
	{
		
		$pass=$_POST['pass'];
		$id=$_POST['id'];
		
		$sql="SELECT * FROM register WHERE UserId='$id'";
		$result=mysqli_query($con, $sql);
		$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
		
		if($row["Password"]==$pass)
		
		{   session_id("log");
		    session_start();
		    
		    setcookie("image", $row["Image"] , "" , "" , "" , "" , true);
		    setcookie("uid", $row["UserId"] , "" , "" , "" , "" , true);
		    setcookie("name", $row["Name"] , "" , "" , "" , "" , true);
		   
		header('Location: index.php');
		}
		else 
		{
			$er=true;
		}
      }
	}

?>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Login</title>
   <meta charset="ISO-8859-1">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">

<!-- Bootstrap Core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="log.css">
<!-- Custom CSS -->
<link href="stylish-portfolio.css" rel="stylesheet">



  </head>
  <body class="mess">
  <img alt="" src="image/log.png" class="left">
  <img alt="" src="image/wow.png" class="right">
   
<a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle">
<i class="fa fa-bars"></i>
</a>
 <nav id="sidebar-wrapper">
<ul class="sidebar-nav">
<a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle">
<i class="fa fa-times"></i>
</a>
<li class="sidebar-brand">
<a class="js-scroll-trigger">  <?php

if(isset($_COOKIE["uid"]))
{  $img=$_COOKIE["image"];
?>
             <?php  echo "<img  src = '$img' height=50px; width=70px/>";?>
              </a></li>
              
              <li>
              <a class="js-scroll-trigger" style="color: white" >
          	<?php echo $_COOKIE["name"];
          }
          else 
          {?>
          	</a></li>
          	<li>
         
        </li>
        <?php }?>
      
        <?php if(isset($_COOKIE["uid"]))
        {?>
         <li>
          <a class="js-scroll-trigger" href="#">Update Account</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="#">Open Profile</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="tg_setaval.php"> Availability</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="logout.php"> Logout</a>
        </li>
       <?php }
       else {?>
       <li>
          <a class="js-scroll-trigger" href="index.php">
          <img alt="" src="image/aaaaaaaaa.png" height="100px" width="150px"> </a>
        </li>
       <li>
          <a class="js-scroll-trigger" href="register.php">sign Up!</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="login.php">Login</a>
        </li>
       <?php } ?>
       <li>
        
      </ul>
    </nav>
    
       <div class="login-page">
       
  <div class="form">
  
    
    <form class="login-form" method="post">
    <img alt="" src="image/aaaaaaaaa.png" height="100px" width="150px">
    <p align="center" > Login to Explore</p>
    <?php if($er==true) echo '<span style="color:red;text-align:center;">Invalid Username or password</span>';?>
      <input type="text" name="id" placeholder="username" />
      <input type="password" name="pass"  placeholder="password"/>
      <button type="submit" name="login">login</button>
      <p class="message">Not registered? <a href="register.php">Create an account</a></p>
      <p class="message">Forgot <a href="register.php">Password? </a></p>
    </form>
  </div>
</div>
   

 <footer>
      <div class="container" id="c">
      
        <div class="row">
          <div class="col-lg-10 mx-auto text-center" >
            <h4>
              <strong >Tourlancer</strong>
            </h4>
            <p >Developed by: <a href="#">Soham Chakrabarti</a> & <a href="#">Soumit sarkar</a></p>
            <ul class="list-unstyled">
              <li>
              Contact us:<br>
                <i class="fa fa-phone fa-fw"  ></i> 
                (+91) 8961177862</li>
                <li>
                <i class="fa fa-phone fa-fw"  ></i>
                (+91) 7044750098</li>
              <li>
               or Mail us at:<br>
                <i class="fa fa-envelope-o fa-fw"></i> 
                <a href="mailto:name@example.com" >soham17041998@gmail.com</a>
              </li>
              <li>
                <i class="fa fa-envelope-o fa-fw"></i>
                <a href="mailto:name@example.com" >soumitcse10@gmail.com</a>
              </li>
            </ul>
            <br>
            <ul class="list-inline">
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-facebook fa-fw fa-3x"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-twitter fa-fw fa-3x"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-dribbble fa-fw fa-3x"></i>
                </a>
              </li>
            </ul>
            <hr class="small">
            <p class="text-muted">Copyright &copy; Tourlancer</p>
          </div>
        </div>
      </div>
      <a id="to-top" href="#top" class="btn btn-dark btn-lg js-scroll-trigger">
        <i class="fa fa-chevron-up fa-fw fa-1x"></i>
      </a>
    </footer>
			<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/stylish-portfolio.js"></script>
   
  </body>
</html>
