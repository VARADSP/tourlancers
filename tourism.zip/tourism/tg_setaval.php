<!DOCTYPE html>
<html><?php
if(isset($_COOKIE["uid"])){
	session_id("log");
	session_start();
}
else {
	header('Location: login.php');
}
$plcID;
if(isset($_COOKIE["uid"]))
{
	$id_a=$_COOKIE["uid"];
    if($_SERVER['REQUEST_METHOD']=='POST')
    {
	     if(isset($_POST['submit']))
	     {
		
	     	$servername="208.91.198.170";
	     	$username="tourlwg2_root";
	     	$password="g2]3T2ZAw8";
	     	$database="tourlwg2_tour";
		
		$con=mysqli_connect($servername,$username,$password,$database);
		$df=$_POST['date_from'];
		$dt=$_POST['date_to'];
		$amt=  $_POST['fee'];
		$dur= $_POST["duration"];
		$fee="INR ".$amt." / ".$dur;
		$resume= $_POST['resume'];
		$placeID=$_POST['add'];
		
		if((empty($df))||(empty($dt))||(empty($amt))||(empty($dur))||(empty($fee))||(empty($resume)))
		{?><div class="alert warning">
  <span class="closebtn">&times;</span>  
  <strong>Invalid! </strong>Please fill the entire form.
</div><?php }
else {
		$sql="INSERT INTO aval(UserId, date_from, date_to, fee, resume, placeID)
		VALUES('$id_a', '$df', '$dt', '$fee', '$resume', '$placeID')";

		if (mysqli_query($con, $sql)) {?>
			<div class="alert success">
  <span class="closebtn">&times;</span>  
  <strong>Congartulations! </strong> You are now a tour Guide.
</div>
		<?php } else {?>
			<div class="alert warning">
			<span class="closebtn">&times;</span>
			<strong>Invalid! </strong> Please Fill again.
			</div>
		<?php }
	}
	     }
	
	
	}
}
?>


<head><meta charset="ISO-8859-1">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<title>Availibility</title>
<style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      .controls {
        background-color: #fff;
        border-radius: 2px;
        border: 1px solid transparent;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        box-sizing: border-box;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        height: 29px;
        margin-left: 10px;
        margin-top: 10px;
        outline: none;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        width: 400px;
      }

      .controls:focus {
        border-color: #4d90fe;
      }
      .title {
        font-weight: bold;
      }
      #infowindow-content {
        display: none;
      }
      #map #infowindow-content {
        display: inline;
      }

.alert {

    padding: 20px;
    background-color: #2196F3;;
    color: white;
}
.alert.success {background-color: #4CAF50;}
.alert.info {background-color: #2196F3;}
.alert.warning {background-color: red;}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
    </style>
<!-- Bootstrap Core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

<!-- Custom CSS -->
<link href="stylish-portfolio.css" rel="stylesheet">
<link rel="stylesheet" href="log.css">

<script>
      // This sample uses the Place Autocomplete widget to allow the user to search
      // for and select a place. The sample then displays an info window containing
      // the place ID and other information about the place that the user has
      // selected.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">
var pID;
      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -33.8688, lng: 151.2195},
          zoom: 13
        });

        var input = document.getElementById('pac-input');

        var autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);

        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        var infowindow = new google.maps.InfoWindow();
        var infowindowContent = document.getElementById('infowindow-content');
        infowindow.setContent(infowindowContent);
        var marker = new google.maps.Marker({
          map: map
        });
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });

        autocomplete.addListener('place_changed', function() {
          infowindow.close();
          var place = autocomplete.getPlace();
          if (!place.geometry) {
            return;
          }

          if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
          } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);
          }

          // Set the position of the marker using the place ID and location.
          marker.setPlace({
            placeId: place.place_id,
            location: place.geometry.location
          });
          marker.setVisible(true);

          infowindowContent.children['place-name'].textContent = place.name;
          infowindowContent.children['place-id'].textContent = place.place_id;
         
          infowindowContent.children['place-address'].textContent =
              place.formatted_address;
          infowindow.open(map, marker);
          pID=place.place_id;
          });
       
      }function clicked(){ 
      document.getElementById('place-id-show').style.color = "green";
     
      document.getElementById('place-id-show').value = pID;}

      function clicked2(){ 
         
          document.getElementById('add').value = pID;
        }
          
      
    </script>
   
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBiJlqWafmoIvGLVAQohVN8gl4zTj6fv-s&libraries=places&callback=initMap"
        async defer></script>

</head>
<body class="mess">
<img alt="" src="">
<a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle">
<i class="fa fa-bars"></i>
</a>
<nav id="sidebar-wrapper">
<ul class="sidebar-nav">
<a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle">
<i class="fa fa-times"></i>
</a>
<li class="sidebar-brand">
<a class="js-scroll-trigger">  <?php

if(isset($_SESSION["uid"]))
{  $img=$_SESSION["image"];
?>
             <?php  echo "<img  src = '$img' height=50px; width=70px/>";?>
              </a></li>
              
              <li>
              <a class="js-scroll-trigger" style="color: white" >
          	<?php echo $_SESSION["name"];
          }
          else 
          {?>
          	</a></li>
          	
        </li>
        <?php }?>
        <li>
          <a class="js-scroll-trigger" href="index.php">Home</a>
        </li>
        <?php if(isset($_SESSION["uid"]))
        {?>
         <li>
          <a class="js-scroll-trigger" href="update.php">Update Account</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="prof.php">Open Profile</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="tg_setaval.php"> Availability</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="logout.php"> Logout</a>
        </li>
       <?php }
       else {}?>
       
      </ul>
    </nav>
	


 <div class="login-page">
<h1 align="center" style="color: black">Set Availibility</h1>
<img alt="" src="image/tgavail.png" class="left">
<div class="form">
<form class="login-form" method="post" id="form" name="form">
     <label>Available:</label><br>
     From: <input type="date" name="date_from" placeholder="Date from">
     To: <input type="date" name="date_to" placeholder="Date to">
     <input id="pac-input" class="controls" type="text"
        placeholder="Enter a location" >
    <div id="map" style="height: 300px; width: 300px;"></div>
    <div id="infowindow-content">
      <span id="place-name"  class="title"></span><br>
      Place ID <span id="place-id"></span><br>
      <span id="place-address"></span>
      
       
    </div>
     <input type="text" name="place-id-show" id="place-id-show"  value="Location ID" disabled="disabled" onclick="clicked()" >
    
      <?php  echo '<span style="color:blue;text-align:center;">*This will display your Location ID.  Verify!'?>
      <input type="text" name="fee" placeholder="Enter Tour package amount per " onclick="clicked()">
      <select  name="duration">
         <option>--select--</option>
         <option value="1 hour">1hour</option>
         <option value="2 hour">2hour</option>
         <option value="4 hour">4hour</option>
         <option value="6 hour">6hour</option>
          <option value="8 hour">8hour</option>
          <option value="12 hour">12hour</option>
       <option value="day">day</option>
       <option value="Lump-sum">Lump-sum</option>
      </select>
      <input type="text" name="resume"  placeholder="Write a short resume" maxlength="100" style="padding-bottom:60px; font-variant: small-caps;">
      <h5>Tips of Writing Good Resume: </h5><br>
      <ul>
      
      <li>Mention your experience with various tour Guides.</li>
      <li>How Long a local?</li>
       <li>Flaunt your knowledge</li>
      </ul>
      <input type="hidden" name="add" id="add" >
      <button type="submit" name="submit"  onclick="clicked2()">Add</button>
     
    </form>
  </div>
  </div>


	<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/stylish-portfolio.js"></script>
</body>
<footer>
      <div class="container" id="c">
      
        <div class="row">
          <div class="col-lg-10 mx-auto text-center" >
            <h4>
              <strong >Tourlancer</strong>
            </h4>
            <p >Developed by: <a href="#">Soham Chakrabarti</a> & <a href="#">Soumit sarkar</a></p>
            <ul class="list-unstyled">
              <li>
              Contact us:<br>
                <i class="fa fa-phone fa-fw"  ></i> 
                (+91) 8961177862</li>
                <li>
                <i class="fa fa-phone fa-fw"  ></i>
                (+91) 7044750098</li>
              <li>
               or Mail us at:<br>
                <i class="fa fa-envelope-o fa-fw"></i> 
                <a href="mailto:name@example.com" >soham17041998@gmail.com</a>
              </li>
              <li>
                <i class="fa fa-envelope-o fa-fw"></i>
                <a href="mailto:name@example.com" >soumitcse10@gmail.com</a>
              </li>
            </ul>
            <br>
            <ul class="list-inline">
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-facebook fa-fw fa-3x"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-twitter fa-fw fa-3x"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-dribbble fa-fw fa-3x"></i>
                </a>
              </li>
            </ul>
            <hr class="small">
            <p class="text-muted">Copyright &copy; Tourlancer</p>
          </div>
        </div>
      </div>
      <a id="to-top" href="#top" class="btn btn-dark btn-lg js-scroll-trigger">
        <i class="fa fa-chevron-up fa-fw fa-1x"></i>
      </a>
    </footer>
</html>
