<?php
if(isset($_COOKIE["uid"])){
	session_id("log");
	session_start();
}
else {
	header('Location: login.php');
}

setcookie("uid", "", time() - 3600);
setcookie("name", "", time() - 3600);
setcookie("image", "", time() - 3600);
setcookie("idd","", time() -3600);
session_id("log");
session_unset();
session_destroy();

header('Location: index.php');

?>