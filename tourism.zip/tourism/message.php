<!DOCTYPE html>
		    		<html>
		    		<head>
		    		<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    
		    		<link rel="stylesheet" href="./style.css"></link>
		    		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<title>Notifications</title>
<!-- Bootstrap Core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="css/w3.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

<!-- Custom CSS -->
<link href="stylish-portfolio.css" rel="stylesheet">
<link rel="stylesheet" href="log.css">
<script src="jquery-3.2.1.min.js">
</script>
<style type="text/css">
.alert {

    padding: 20px;
    background-color: #2196F3;;
    color: white;
}
.alert.success {background-color: #4CAF50;}
.alert.info {background-color: #2196F3;}
.alert.warning {background-color: #ff9800;}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}</style>


	
	</head>
<body class="mess">
<img alt="" src="image/mes.png" class="center" style="opacity: 20%"
>
<a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle">
<i class="fa fa-bars"></i>
</a>
<nav id="sidebar-wrapper">
<ul class="sidebar-nav">
<a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle">
<i class="fa fa-times"></i>
</a>
<li class="sidebar-brand">
<a class="js-scroll-trigger">  <?php
$servername="208.91.198.170";
$username="tourlwg2_root";
$password="g2]3T2ZAw8";
$database="tourlwg2_tour";
$con=mysqli_connect($servername,$username,$password,$database);
$b=0;
$m=0;
$stat=0; 
if(isset($_COOKIE["uid"])){
	session_id("log");
	session_start();
}
else {
	header('Location: login.php');
}
if(isset($_COOKIE["uid"]))
{  $img=$_COOKIE["image"];
?>
             <?php  echo "<img  src = '$img' height=50px; width=70px/>";?>
              </a></li>
              
              <li>
              <a class="js-scroll-trigger" style="color: white" >
          	<?php echo $_COOKIE["name"];
          }
          else 
          {?>
          	</a></li>
          	
        <?php }?>
        <li>
          <a class="js-scroll-trigger" href="index.php">Home</a>
        </li>
        <?php if(isset($_COOKIE["uid"]))
        {?>
         <li>
          <a class="js-scroll-trigger" href="update.php">Update Account</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="prof.php">Open Profile</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="tg_setaval.php"> Availability</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="logout.php"> Logout</a>
        </li>
       <?php }
       else {?>
       <li>
          <a class="js-scroll-trigger" href="register.php">sign Up!</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="login.php">Login</a>
        </li>
       <?php } ?>
       
      </ul>
    </nav>
    <div class="w3-card-2 w3-margin">
    <?php 
   $stat; $us;
    $avid;
    $not=$_COOKIE["uid"];

    $sql="SELECT * FROM (SELECT * FROM messages ORDER BY time DESC )messages WHERE guideId='$not' ";
    $result=mysqli_query($con, $sql);
    
    if($_SERVER['REQUEST_METHOD']=='POST')
    {
    if(isset($_POST['confirm']))
    {   
    	
    	?>
    	
    	<?php 
    	
    	 $id=$_POST['confirm'];
    	 $sql6="SELECT * FROM messages WHERE id='$id' ";
    	 $result3=mysqli_query($con, $sql6);
         $msg=" has accepted your booking. For more Enquiry, contact him. The details will be mailed soon. Hope to make your trip a successful one.";
         $gui=$_COOKIE["name"];
         $today = date("F j, Y, g:i a");
         while($row4 = mysqli_fetch_assoc($result3)) { $us= $row4["Name"];}
    	$sql="INSERT INTO booked
    	( guideId, Message, userId, date, status, id)
    	VALUES( '$gui', '$msg','$us','$today', '1', '$id')";
			mysqli_query($con, $sql);
			
			$sq="UPDATE messages SET status='1' WHERE id='$id'";
			mysqli_query($con, $sq);?>
  
			<?php 
			}?>
  
				<?php 
				if(isset($_POST['cancel']))
				{ 
					?>
						$id=$_POST['cancel'];
				$s="DELETE FROM messages WHERE id='$id'";
				mysqli_query($con, $s);
				header('Location: message.php');
				
				<?php }
			
    }
			
    
    $sql1="SELECT * FROM (SELECT * FROM booked ORDER BY date DESC )booked WHERE userId='$not' ";
    $result1=mysqli_query($con, $sql1);
    // output data of each row
    $m=count(mysqli_fetch_array($result));
    $b=count(mysqli_fetch_array($result1));
    while($row = mysqli_fetch_assoc($result)) { ?>
    	<form method="post">
    	 <span style="height: 30px; color: red"><u>TourGuide Messages</u></span>
		<ul class="w3-ul w3-hoverable w3-white">
            <li class="w3-padding-16">
             <span class="w3-large">
             
            
              
              <span><?php  echo $row["Name"].$row["Message"];?></span><br>
              <span>ID: <?php echo $row["id"];?> </span>
              <span class="w3-padding-large w3-right"><?php echo $row["time"]; ?> </span>
              </span>
              <span id="text" class="w3-padding-large w3-right"></span>
            <?php $n1=$row["id"];
            $sql_="SELECT * FROM messages WHERE id='$n1' ";
            $result_=mysqli_query($con, $sql_);
            while($_row_ = mysqli_fetch_assoc($result_)) { $stat= $_row_["status"];}
            if($stat!=1){
              ?>
             
               <button type="submit" name="confirm" value="<?php echo $row['id'];?>" id="confirm" onclick="myFunction()">Confirm him</button>
              <button type="submit" name="cancel" value="<?php echo $row['id'];?>" id="cancel" onclick="myFunction2()">Cancel</button>
              <?php }
              else {
              ?> <p style="color: green; font-size: 25px; font-style: oblique;">Booked</p><?php }?>
              </li>
              
              </ul>
              </form>
              <span style="height: 30px; color: red"><u>Booked Messages</u></span>
    <?php }
    
    while($row1 = mysqli_fetch_assoc($result1)) {?>
    	<form method="post">
		<ul class="w3-ul w3-hoverable w3-white">
            <li class="w3-padding-16">
             <span class="w3-large">
              <span><?php echo $row1["guideId"].$row1["Message"]; ?> </span>
              <span class="w3-padding-large w3-right"><?php echo $row1["date"];?> </span>
              </span>
              
              </li>
              
              </ul>
              </form>
    <?php }
    ?>
    </div>
    
    <?php  if(($m>0) && ($b>0)){?>
    <div class="alert info">
  <span class="closebtn">&times;</span>  
  <strong>Sorry!</strong> You have no messages.
</div><?php }?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/stylish-portfolio.js"></script>
    </body>
    </html>
    
    