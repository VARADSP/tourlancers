<!DOCTYPE html>
<html>
<head>
<style>
.alert {

    padding: 20px;
    background-color: #2196F3;;
    color: white;
}
.alert.success {background-color: #4CAF50;}
.alert.info {background-color: #2196F3;}
.alert.warning {background-color: red;}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}</style></head>
<body><?php
if($_SERVER['REQUEST_METHOD']=='POST')
{
	if(isset($_POST['submit']))
	{$servername="localhost:3306";
	$username="tourlwg2_root";
	$password="g2]3T2ZAw8";
	$database="tourlwg2_tour";
		
		$con=mysqli_connect($servername,$username,$password,$database);
		
		
		$id=$_POST['id'];
		$name=$_POST['name'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$contact=$_POST['contact'];
		$dob=$_POST['dob'];
		$gender=$_POST['gender'];
		$city=$_POST['city'];
		$state=$_POST['state'];
		$abu=$_POST['abu'];
		$lang = implode(",",$_POST["la"]);
		$ad=$_POST['adh'];
		$pan=$_POST['pan'];
		$pass=$_POST['pass'];
		$pass2==$_POST['pass2'];
		
		
		if($pass2!=$pass) { header('Location: register.php');}
		
		$target_dir="profilePic/";
		$target_file=$target_dir.basename($_FILES["image"]["name"]);
		$imageFileType= pathinfo($target_file,PATHINFO_EXTENSION);
		
		move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
		
		
		if((empty($id))||(empty($name))||(empty($address))||(empty($email))||(empty($city))||(empty($contact))||(empty($dob))||(empty($id))
				||(empty($gender))||(empty($city))||(empty($abu))||(empty($lang))||(empty($pass)))
		{
		 header('Location: register.php');
		 
			
		}
		else {
			if((empty($ad)||empty($pan))){
				$sql="INSERT INTO register(UserId, Name, Address, Email, contact, Dob, Gender, Image, City, state, Password, About, lang, adhn, pan)
				VALUES('$id', '$name', '$address', '$email', '$contact', '$dob', '$gender', '$target_file', '$city', '$state', '$pass', '$abu' ,'$lang', '---', '---')";
				mysqli_query($con, $sql);
			}
			$sql="INSERT INTO register(UserId, Name, Address, Email, contact, Dob, Gender, Image, City, state, Password, About, lang, adhn, pan)
			VALUES('$id', '$name', '$address', '$email', '$contact', '$dob', '$gender', '$target_file', '$city', '$state', '$pass', '$abu' ,'$lang', '$ad', '$pan')";
			mysqli_query($con, $sql);?><div class="alert success">
  <span class="closebtn">&times;</span>  
  <strong>Congartulations! </strong> You are now a tour Guide.
</div><?php 
		}
	}
}?>
</body>
</html>

