<?php
if(isset($_COOKIE["uid"])){
	session_id("log");
	session_start();
}
$servername="208.91.198.170";
$username="tourlwg2_root";
$password="g2]3T2ZAw8";
$database="tourlwg2_tour";
$con=mysqli_connect($servername,$username,$password,$database);
if($_SERVER['REQUEST_METHOD']=='POST')
{
	if(isset($_POST['hit']))
	{session_write_close();
	
	
	session_id("prof");
	session_start();
	setcookie("idd",$_POST['search']);
	
	$uid=$_COOKIE["idd"];
	$sql7= "SELECT * FROM register WHERE UserId='$uid'";
	$result7=mysqli_query($con, $sql7);
	// output data of each row
	if(count( mysqli_fetch_assoc($result7))!=0){
		while($row7 = mysqli_fetch_assoc($result7)) {
			if($row7["UserId"]==$_COOKIE["idd"])
			{
				$nm=$row1["Name"];
				
				header('Location: prof2.php');
			}
			
			
			
		}
	}
	else echo "not found";
	
	}
}
if(isset($_COOKIE["idd"])){
	setcookie("idd","", time() -3600);
	session_id("prof");
	session_unset();
	session_destroy();
}
?>
<!DOCTYPE html>
<html lang="en">
<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
  <head>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">


img:hover {
  animation: shake 0.5s;
  animation-iteration-count: infinite;
}

@keyframes shake {
  0% { transform: translate(1px, 1px) rotate(0deg); }
  10% { transform: translate(-1px, -2px) rotate(-1deg); }
  20% { transform: translate(-3px, 0px) rotate(1deg); }
  30% { transform: translate(3px, 2px) rotate(0deg); }
  40% { transform: translate(1px, -1px) rotate(1deg); }
  50% { transform: translate(-1px, 2px) rotate(-1deg); }
  60% { transform: translate(-3px, 1px) rotate(0deg); }
  70% { transform: translate(3px, 1px) rotate(-1deg); }
  80% { transform: translate(-1px, -1px) rotate(1deg); }
  90% { transform: translate(1px, 2px) rotate(0deg); }
  100% { transform: translate(1px, -2px) rotate(-1deg); }
}
#map {
        width: 100%;
 }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #description {
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
      }

      #infowindow-content .title {
        font-weight: bold;
      }

      #infowindow-content {
        display: none;
      }

      #map #infowindow-content {
        display: inline;
      }

      .pac-card {
        margin: 10px 10px 0 0;
        border-radius: 2px 0 0 2px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        outline: none;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        background-color: #fff;
        font-family: Roboto;
      }

      #pac-container {
        padding-bottom: 12px;
        margin-right: 12px;
      }

      .pac-controls {
        display: inline-block;
        padding: 5px 11px;
      }

      .pac-controls label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }

      #pac-input {
        background-color: #fff;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        margin-left: 12px;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        width: 400px;
      }

      #pac-input:focus {
        border-color: #4d90fe;
      }

      #title {
        color: #fff;
        background-color: #4d90fe;
        font-size: 25px;
        font-weight: 500;
        padding: 6px 12px;
       
      }
      .controls {
        background-color: #fff;
        border-radius: 2px;
        border: 1px solid transparent;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        box-sizing: border-box;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        height: 29px;
        margin-left: 10px;
        margin-top: 10px;
        outline: none;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        width: 400px;
      }

      .controls:focus {
        border-color: #4d90fe;
      }
      .title {
        font-weight: bold;
      }
      #infowindow-content {
        display: none;
      }
      #map #infowindow-content {
        display: inline;
      }
       .pac-controls label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }
      .button-link {
	padding: 10px 15px;
	background: #4479BA;
	color: #FFF;
	margin-left: 40px;
}

      #pac-input {
        background-color: #fff;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        margin-left: 12px;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        width: 400px;
      }

      #pac-input:focus {
        border-color: #4d90fe;
      }

      #title {
        color: #fff;
        background-color: #4d90fe;
        font-size: 25px;
        font-weight: 500;
        padding: 6px 12px;
        }
        #floating-panel {
        position: absolute;
        top: 10px;
        left: 25%;
        z-index: 5;
        background-color: #fff;
        padding: 5px;
        border: 1px solid #999;
        text-align: center;
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
      }
      #floating-panel {
        width: 440px;
      }
      #place-id {
        width: 250px;}
        .s {
    width: 200px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

.s[type=text]:focus {
    width: 50%;}
    
    input[type=text] {
    width: 100%;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}
        
      }
      
      </style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	
    <title>tour Lancer</title>
<link rel="shortcut icon" href="your_image_path_and_name.ico" />
    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="https://maps.googleapis.com/maps/api/place/autocomplete/json?input=&types=geocode&key=AIzaSyBiJlqWafmoIvGLVAQohVN8gl4zTj6fv-s" >

    <!-- Custom CSS -->
    <link href="stylish-portfolio.css" rel="stylesheet"> 
    
     
   
<script src="jquery-3.2.1.min.js">
</script>



  </head>

 
    <!-- Navigation -->
    <a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle">
      <i id="nav" class="fa fa-bars" > </i>
      
    </a>

    <nav id="sidebar-wrapper">
    
      <ul class="sidebar-nav">
        <a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle">
          <i class="fa fa-times"></i>
        </a>
        <li class="sidebar-brand">
          <a class="js-scroll-trigger">  <?php 
          if(isset($_COOKIE["uid"]))
          {  $img=$_COOKIE["image"];
          ?>
            
             <img alt="" src="<?php echo $img;?>" height=100px; width=120px; style= "border-radius:50%"/> 
              </a></li>
              
              <li>
              <a class="js-scroll-trigger" style="color: white" ><br>
          	<?php echo $_COOKIE["name"];
          }
          else 
          {?>
          	</a></li>
          	<li>
          <a class="js-scroll-trigger" href="index.php">
          <img alt="" src="image/aaaaaaaaa.png" height="100px" width="150px"> </a>
        </li>
        <?php }?>
       
        <?php if(isset($_COOKIE["uid"]))
        {?>
         <li>
          <a class="js-scroll-trigger" href="update.php">Update Account</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="prof.php">Open Profile</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="tg_setaval.php"> Availability</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="logout.php"> Logout</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="message.php">Notifications</a>
          
        </li>
       <?php }
       else {?>
       <li>
          <a class="js-scroll-trigger" href="register.php">sign Up!</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="login.php">Login</a>
        </li>
       <?php } ?>
       <li>
          <a class="js-scroll-trigger" href="#map">Find Guides</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="#about">About</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="#services">Services</a>
        </li>
       <li>
        <li>
          <a class="js-scroll-trigger" href="#portfolio">Gallery</a>
        </li>
       <li>
          <a class="js-scroll-trigger" href="#c">Contacts</a>
        </li>
        
      </ul>
    </nav>

    <!-- Header -->
    <header class="header" id="top" >
      <div class="text-vertical-center" >
       <img alt="TL" src="image/aaaaaaaaa.png">
        <h3 style="color: white">travel with ease &nearr;</h3>
        <br>
        
        <a href="#about"  class='btn btn-dark btn-lg js-scroll-trigger'>Start Exploring</a><br><br>
        
        <?php if(!isset($_COOKIE["uid"])){?><a href="login.php" class="btn btn-dark btn-lg js-scroll-trigger">Log in</a>
     <?php }?>
        <?php if(isset($_COOKIE["uid"])){?><a href="prof.php" class="btn btn-dark btn-lg js-scroll-trigger">Go to Profile</a>
     <?php }?> <form  method="post"><br>
  <input class="s" type="text" name="search" placeholder="Search by ID"> <button class="w3-xxlarge  fa fa-search" type="submit" name="hit" ></button>
  
</form></div>
    
    </header>

    <!-- About -->
    <section id="about" class="about" >
      <div class="container text-center">
       
         <h2 >Love travelling?</h2>
        <p class="lead" >Tourlancer provides you the most verified tour guides from around the World.
        Just specify your tour dates and locations and get going. </p>
         <h2 >Out of Money?</h2>
         <p class="lead" > Brace Yourselves! We provide a platform for you to earn by working as a tour guide in your area.
         Stop dreaming and get started to act as a local guide and earn bucks.
          </p>
      </div>
      <!-- /.container -->
    </section>

    <!-- Services -->
    <section id="services" class="services bg-primary text-white">
      <div class="container">
        <div class="row text-center">
          <div class="col-lg-10 mx-auto">
            <h2>Services</h2>
            <hr class="small">
            <div class="row">
              <div class="col-md-3 col-sm-6">
                <div class="service-item">
                  <span class="fa-stack fa-4x">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-cloud fa-stack-1x text-primary"></i>
                  </span>
                  <h4>
                    <strong>TourLancing</strong>
                  </h4>
                  <p>We Provide a platform for people all over India, who want to serve as a tourGuide in their free time. 
                  tourLancer makes travelling easy, by connecting tourists with Guides in a fashionable way.
                  Just Apply as a Guide and get Going! </p>
                  <a href="#map" class="btn btn-light">Explore</a>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="service-item">
                  <span class="fa-stack fa-4x">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-compass fa-stack-1x text-primary"></i>
                  </span>
                  <h4>
                    <strong>Review Guides</strong>
                  </h4>
                  <p>
                  We have a built-in system, where the tourists review and rate the tourGuides.
                  Tourists share their experience with us, and make people more aware of the best tourGuides in the country.
                  A tough competition for the Guides, I guess!</p>
                 
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="service-item">
                  <span class="fa-stack fa-4x">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-flask fa-stack-1x text-primary"></i>
                  </span>
                  <h4>
                    <strong>Get Certified</strong>
                  </h4>
                  <p>Want more tourists? Here, we have the certification system, enabling you to get Certified
                  as a Professional tourGuide, and increase your reputation.
                  Just appear for the test, and get promoted. 
                  This helps you attract tourists toward you.</p>
                  <a href="#" class="btn btn-light">Coming soon...</a>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="service-item">
                  <span class="fa-stack fa-4x">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-shield fa-stack-1x text-primary"></i>
                  </span>
                  <h4>
                    <strong>Subscriptions</strong>
                  </h4>
                  <p> Go get your Premium Account for your better Profile.
                  Remember, tourits only prefer Guides with full-proof identity and a Verified one. 
                  Get, tourLancer verified and give a head start to your earnings.</p>
                  <a href="#" class="btn btn-light">Coming soon...</a>
                </div>
              </div>
            </div>
            <!-- /.row (nested) -->
          </div>
          <!-- /.col-lg-10 -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>

    <!-- Callout -->
  

    <!-- Portfolio -->
    <section id="portfolio" class="portfolio" style="background-color:#000000">
      <div class="container" >
        <div class="row">
          <div class="col-lg-10 mx-auto text-center">
            <h2 style="color: white">Gallery</h2>
            <hr class="small">
            <div class="row">
              <div class="col-md-6">
                <div class="portfolio-item">
                  <a href="#portfolio">
                    <img class="img-portfolio img-fluid" src="image/London-City-wallpapers.jpg" style="opacity: 20%">
                  </a>
                </div>
              </div>
              <div class="col-md-6">
                <div class="portfolio-item">
                  <a href="#portfolio">
                    <img class="img-portfolio img-fluid" src="image/Goa-10.jpg">
                  </a>
                </div>
              </div>
              <div class="col-md-6">
                <div class="portfolio-item">
                  <a href="#portfolio">
                    <img class="img-portfolio img-fluid" src="image/Eiffel-Tower_HD.jpg">
                  </a>
                </div>
              </div>
              <div class="col-md-6">
                <div class="portfolio-item">
                  <a href="#portfolio">
                    <img class="img-portfolio img-fluid" src="image/CkQHKGx.jpg">
                  </a>
                </div>
              </div>
            </div>
            <!-- /.row (nested) -->
           
          </div>
          <!-- /.col-lg-10 -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>

   
  <section class="map" id="map">
           <iframe width="100%" height="100%" frameborder="4" scrolling="no" marginheight="0" marginwidth="0" ></iframe> 
    
     
</section>
     

<div id="infowindow-content">
      <span id="place-name"  class="title"></span><br>
      Place ID <span id="place-id"></span><br>
      <span id="place-address"></span></div>
 <div class="text-vertical-center" >
     <aside id="sidebar" >
     
        
  
          <div class="pac-card" id="pac-card" draggable="true">
      <div>
        <div id="title">
          Find your Guide Now
        </div>
       <form   action="set_aval.php" method="post">
  						<div >
  							<label style="font-size: 20px; margin-left: 30px">Tour starts at</label><br>
  							<input style="font-size: 20px; margin-left: 30px" type="date" placeholder="date_from" name="date_from" >
  						</div>
  						<div>
  							<label style="font-size: 20px; margin-left: 30px;">Tour ends at</label><br>
  							<input style="font-size: 20px; margin-left: 30px;" type="date" placeholder="date_to" name="date_to">
  						</div>
  						
  						
  						
  							
        <input id="pac-input" class="controls" type="text" 
        placeholder="Enter a location" >
                 <input type="hidden" name="place-id-show" id="place-id-show"  value="" onclick="clicked()" >
                 <button class="w3-xxxlarge w3-spin fa fa-search" type="submit" name="submit" style="color: black" onclick="clicked()"></button>
     
   
   
    	
    </form>
    </div>
    </div>
    </aside>
    </div>
     <div>
        
      </div>
    <!-- Footer -->
    
<script type="text/javascript">

var pID;
   function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -33.8688, lng: 151.2195},
          zoom: 13
        });

        var input = document.getElementById('pac-input');

        var autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);

        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        var infowindow = new google.maps.InfoWindow();
        var infowindowContent = document.getElementById('infowindow-content');
        infowindow.setContent(infowindowContent);
        var marker = new google.maps.Marker({
          map: map
        });
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });

        autocomplete.addListener('place_changed', function() {
          infowindow.close();
          var place = autocomplete.getPlace();
          if (!place.geometry) {
            return;
          }

          if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
          } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);
          }

          // Set the position of the marker using the place ID and location.
          marker.setPlace({
            placeId: place.place_id,
            location: place.geometry.location
          });
          marker.setVisible(true);

          infowindowContent.children['place-name'].textContent = place.name;
          infowindowContent.children['place-id'].textContent = place.place_id;
         
          infowindowContent.children['place-address'].textContent =
              place.formatted_address;
          infowindow.open(map, marker);
          pID=place.place_id;
          });
       
      }function clicked(){ 
      document.getElementById('place-id-show').style.color = "green";document.getElementById('place-id-show').value = pID;}
      
    </script>
   
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBiJlqWafmoIvGLVAQohVN8gl4zTj6fv-s&libraries=places&callback=initMap1"
        async defer></script>
   
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBiJlqWafmoIvGLVAQohVN8gl4zTj6fv-s&libraries=places&callback=initAutocomplete"
         async defer></script>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/stylish-portfolio.js"></script>
<script src="resource.js" type="text/javascript"></script>
 
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBiJlqWafmoIvGLVAQohVN8gl4zTj6fv-s&callback=initMap">
    </script>
    <script src="resource.js" type="text/javascript"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBiJlqWafmoIvGLVAQohVN8gl4zTj6fv-s&libraries=places&callback=initMap"
        async defer></script>
  </body>
<footer>
      <div class="container" id="c">
      
        <div class="row">
          <div class="col-lg-10 mx-auto text-center" >
            <h4>
              <strong >Tourlancer</strong>
            </h4>
            <p >Developed by: <a href="#">Soham Chakrabarti</a> & <a href="#">Soumit sarkar</a></p>
            <ul class="list-unstyled">
              <li>
              Contact us:<br>
                <i class="fa fa-phone fa-fw"  ></i> 
                (+91) 8961177862</li>
                <li>
                <i class="fa fa-phone fa-fw"  ></i>
                (+91) 7044750098</li>
              <li>
               or Mail us at:<br>
                <i class="fa fa-envelope-o fa-fw"></i> 
                <a href="mailto:name@example.com" >soham17041998@gmail.com</a>
              </li>
              <li>
                <i class="fa fa-envelope-o fa-fw"></i>
                <a href="mailto:name@example.com" >soumitcse10@gmail.com</a>
              </li>
            </ul>
            <br>
            <ul class="list-inline">
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-facebook fa-fw fa-3x"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-twitter fa-fw fa-3x"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-dribbble fa-fw fa-3x"></i>
                </a>
              </li>
            </ul>
            <hr class="small">
            <p class="text-muted">Copyright &copy; Tourlancer</p>
          </div>
        </div>
      </div>
      <a id="to-top" href="#top" class="btn btn-dark btn-lg js-scroll-trigger">
        <i class="fa fa-chevron-up fa-fw fa-1x"></i>
      </a>
    </footer>
</html>
