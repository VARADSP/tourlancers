<!DOCTYPE html>
<?php
$count=0;$fee;$df;$dt;$id1;$uid;$nm;$id1;
if(isset($_COOKIE["uid"])){
	session_id("log");
	session_start();
}
$servername="208.91.198.170";
$username="tourlwg2_root";
$password="g2]3T2ZAw8";
$database="tourlwg2_tour";
$con=mysqli_connect($servername,$username,$password,$database);
if($_SERVER['REQUEST_METHOD']=='POST')
{
	if(isset($_POST['button']))
	{   
		session_write_close();
		session_id("prof");
		session_start();
		setcookie("idd",$_POST['button'] , time()+3600 , "" , "" , "" , true);
		$uid=$COOKIE["idd"];
		$sql= "SELECT * FROM register WHERE UserId='$uid'";
		$result1=mysqli_query($con, $sql);
		// output data of each row
		while($row1 = mysqli_fetch_assoc($result1)) {
			$nm=$row1["Name"];
		}
		$_SESSION["name1"]=$nm;
		header('Location: prof2.php');
		
		
		
	}
}?>
		    		<html>
		    		<head>
		    		<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Availibility</title>
		    		<link rel="stylesheet" href="./style.css"></link>
		    		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<style type="text/css">
body{
</style>

<style>
.alert {

    padding: 20px;
    background-color: #2196F3;;
    color: white;
}
.alert.success {background-color: #4CAF50;}
.alert.info {background-color: #2196F3;}
.alert.warning {background-color: #ff9800;}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
</style>
<!-- Bootstrap Core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/w3.css">
<!-- Custom Fonts -->
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

<!-- Custom CSS -->
<link href="stylish-portfolio.css" rel="stylesheet">
<link rel="stylesheet" href="log.css"></head>
<body class="mess">
<img alt="" src="image/avail.png" class="center">
<a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle">
<i class="fa fa-bars"></i>
</a>
<nav id="sidebar-wrapper">
<ul class="sidebar-nav">
<a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle">
<i class="fa fa-times"></i>
</a>
<li class="sidebar-brand">
<a class="js-scroll-trigger">  <?php

if(isset($_COOKIE["uid"]))
{  $img=$_COOKIE["image"];
?>
             <?php  echo "<img  src = '$img' height=50px; width=70px/>";?>
              </a></li>
              
              <li>
              <a class="js-scroll-trigger" style="color: white" >
          	<?php echo $_COOKIE["name"];
          }
          else 
          {?>
          	</a><li>
          <a class="js-scroll-trigger" href="index.php">
          <img alt="" src="image/aaaaaaaaa.png" height="100px" width="150px"> </a>
        </li>
        <?php }?>
        <li>
          <a class="js-scroll-trigger" href="index.php">Home</a>
        </li>
        <?php if(isset($_COOKIE["uid"]))
        {?>
         <li>
          <a class="js-scroll-trigger" href="update.php">Update Account</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="prof.php">Open Profile</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="tg_setaval.php"> Availability</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="logout.php"> Logout</a>
        </li>
       <?php }
       else {?>
       	<li>
       	<a class="js-scroll-trigger" href="login.php"> Login</a>
       	</li>
     <?php   }?>
      
      </ul>
    </nav>
<?php 
if($_SERVER['REQUEST_METHOD']=='POST')
	{
		if(isset($_POST['submit']))
		{
			
			
			$df=$_POST['date_from'];
			$dt=$_POST['date_to'];
			$loc_user=$_POST['place-id-show'];
		    $sql_dateChecker= "SELECT * FROM aval ";
		    $result=mysqli_query($con, $sql_dateChecker);
		    while($row1=mysqli_fetch_assoc($result))
		    {
		    	$df_tg=$row1['date_from'];
		    	$dt_tg=$row1['date_to'];
		    	$loc=$row1['placeID'];
		    	$uid=$row1['UserId'];
		    	if($loc==$loc_user)
		    	{  
		    		$start_time_user= strtotime($df);
		    	$end_time_user= strtotime($dt);
		    	$start_time_guide= strtotime($df_tg);
		    	$end_time_guide= strtotime($dt_tg);
		    	
		    	
		    	if(($start_time_user >= $start_time_guide) && ($end_time_user <= $end_time_guide))
		    	{ $count++;
		    		?>
		    		

		    		<div class="w3-card-2 w3-margin">
     		<?php
		    		$sql= "SELECT * FROM register WHERE UserId='$uid'";
		    		$sql1= "SELECT * FROM aval WHERE UserId='$uid'";
		    		$result1=mysqli_query($con, $sql);
		    		$result2=mysqli_query($con, $sql1);
		    		// output data of each row
		    		while($row1 = mysqli_fetch_assoc($result2)) {
		    			$fee=$row1["fee"];
		    			$id1=$row1["id"];
		    			$dt=$row1["date_to"];
		    			$df=$row1["date_from"];
		    			
		    		}
		    		while($row = mysqli_fetch_assoc($result1)) {
		    			$nm=$row["Name"];
		    			$im=$row['Image'];
		    			
		    			?>
		<form method="post">
		<ul class="w3-ul w3-hoverable w3-white">
            <li class="w3-padding-16">
             <span class="w3-large">
               <img alt="" src="<?php echo $im;?>" height=50px; width=50px; style= "border-radius:50%"/> 
              <span><?php echo "".$row["Name"]; ?> </span><br><br>
              <span><?php echo "Package Amt.".$fee;?></span><br>
              <span><?php echo "Availibilty ID.".$id1;?></span><br>
						  <span><?php echo "From:  ".$df." to: ".$dt;?></span>
						  
						  
						   <?php $id1=$row["UserId"]; ?>
						   </span>
						   <br>
						  <button type="submit" name="button" value="<?php echo $id1?>">Check Profile</button>
						 </li>
						 
       </ul>
            </form>
             <?php }
             ?>
             </div>
		    	<?php 
		    		
		    	}
	   	
		    }
		   }
		    if($count==0)
		    {
		    	?><div class="alert info">
  <span class="closebtn">&times;</span>  
  <strong>Sorry!</strong> No Guides Available at this moment or you may not have entered any data. Visit again.Thank you!
</div><?php 
		    	}
		    	else 
		    	{
		    		?><div class="alert success">
  <span class="closebtn">&times;</span>  
  <strong>Congratulations !</strong> We have Guides available in your specified Location. Enjoy your Tour!
</div> <?php 
			}
	}
	}
?>
 </body>
	 
 <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/stylish-portfolio.js"></script>

 </html>
