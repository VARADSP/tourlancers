<!DOCTYPE html>
<html>
<?php
session_id("log");
session_start();
$flag=0;
$err=false;
if(isset($_COOKIE["uid"]))
{
	$row;$res;
	$uid=$_COOKIE["uid"];
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		if(isset($_POST['submit']))
		{
			$servername="208.91.198.170";
			$username="tourlwg2_root";
			$password="g2]3T2ZAw8";
			$database="tourlwg2_tour";
			
			
			$con=mysqli_connect($servername,$username,$password,$database);
			
			
			$name=$_POST['name'];
			$address=$_POST['address'];
			$email=$_POST['email'];
			$contact=$_POST['contact'];
			$dob=$_POST['dob'];
			$gender=$_POST['gender'];
			$city=$_POST['city'];
			$state=$_POST['state'];
			$abu=$_POST['abu'];
			if(!empty($_POST["la"]))
			$lang = implode(",",$_POST["la"]);
			$ad=$_POST['adh'];
			$pan=$_POST['pan'];
			$pass=$_POST['pass'];
			
			
			$target_dir="profilePic/";
			$target_file=$target_dir.basename($_FILES["image"]["name"]);
			$imageFileType= pathinfo($target_file,PATHINFO_EXTENSION);
			
			move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
			
			
			if((empty($name))||(empty($address))||(empty($email))||(empty($city))||(empty($contact))||(empty($dob))||(empty($lang)
					||(empty($gender))||(empty($city))||(empty($abu))||(empty($lang))||(empty($pass))))
			{
				$err=true;
				
			}
			else {
			$uid=$_COOKIE["uid"];
			
			if((empty($ad)||empty($pan))){
				$sql="UPDATE register
				set  Name='$name', Address='$address', Email='$email', contact='$contact', Dob='$dob', gender='$gender',
				Image='$target_file', City='$city', state='$state', Password='$pass', About='$abu', lang='$lang'
				where Userid='$uid'";
				mysqli_query($con, $sql);
				
			}
			else{
			$sql="UPDATE register
			set  Name='$name', Address='$address', Email='$email', contact='$contact', Dob='$dob', gender='$gender',
			Image='$target_file', City='$city', state='$state', Password='$pass',  lang='$lang', About='$abu' adhn='$ad', pan='$pan'
			where Userid='$uid'";
			mysqli_query($con, $sql);
			mysqli_close($con);
			}
			
			?><div class="alert success">
  <span class="closebtn">&times;</span>  
  <strong>Profile Update! </strong>Your Profile Picture will be updated shortly.
</div><?php 
		}
	}
}
}
else 
{
	header('Location: login.php');
}


?>

<head>
<style>
.alert {

    padding: 20px;
    background-color: #2196F3;;
    color: white;
}
.alert.success {background-color: #4CAF50;}
.alert.info {background-color: #2196F3;}
.alert.warning {background-color: red;}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}</style>
</head>


<head>
<meta charset="ISO-8859-1">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">

<!-- Bootstrap Core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

<!-- Custom CSS -->
<link href="stylish-portfolio.css" rel="stylesheet">
<link rel="stylesheet" href="log.css">

<title>Update</title>

<link href="registertodb.php">
<script type="text/javascript">
</script>
</head>
<body class="mess" >

<img alt="" src="image/wel.png" class="left">
<img alt="" src="image/wel.png" class="right welcome">
<a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle">
<i class="fa fa-bars"></i>
</a>
<nav id="sidebar-wrapper">
<ul class="sidebar-nav">
<a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle">
<i class="fa fa-times"></i>
</a>
<li class="sidebar-brand">
<a class="js-scroll-trigger">  <?php

if(isset($_SESSION["uid"]))
{  $img=$_SESSION["image"];
?>
             <?php  echo "<img  src = '$img' height=50px; width=70px/>";?>
              </a></li>
              
              <li>
              <a class="js-scroll-trigger" style="color: white" >
          	<?php echo $_SESSION["name"];
          }
          else 
          {?>
          	</a></li>
          	
        <?php }?>
        <li>
          <a class="js-scroll-trigger" href="index.php">Home</a>
        </li>
        <?php if(isset($_SESSION["uid"]))
        {?>
         <li>
          <a class="js-scroll-trigger" href="update.php">Update Account</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="prof.php">Open Profile</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="tg_setaval.php"> Availability</a>
        </li>
         <li>
          <a class="js-scroll-trigger" href="logout.php"> Logout</a>
        </li>
       <?php }
       else {?>
       <li>
          <a class="js-scroll-trigger" href="register.php">sign Up!</a>
        </li>
        <li>
          <a class="js-scroll-trigger" href="login.php">Login</a>
        </li>
       <?php } ?>
       
      </ul>
    </nav>
	
		
 <div class="login-page" >
 <div class="form" style="width: 100%">
 <img alt="" src="image/aaaaaaaaa.png" height="100px" width="150px">
 
		
		
		<?php 
		
		$servername="localhost";
		$username="root";
		$password="";
		$database="tour";
		
		$con=mysqli_connect($servername,$username,$password,$database);
		$sql1="SELECT * FROM register
		where Userid='$uid'";
		$res=mysqli_query($con, $sql1);
		while($row= mysqli_fetch_assoc($res)) {?>
		
			
			<h2 align="center"><u>Update</u></h2>
			<form  class="login-form"  method="post"  enctype="multipart/form-data">
			<table>
			<tr>
			<td>
			<?php if($err==true) echo '<span style="color:red;">*Please fill out the details</span>';?>
			</td>
			</tr>
			<tr>
				<td>User ID
				<input type="text" name="id" id="userid" disabled="disabled" value="<?php echo $_SESSION["uid"];?>" ></td>
				
			</tr>
			<tr>
				<td>Full Name</td>
				<td><input type="text" name="name"></td>
			</tr>

			<tr>
				<td>Address</td>
				<td><input type="text" name="address"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email"></td>
			</tr>
			<tr>
				<td>Contact No</td>
				<td><input type="text" name="contact"></td>
			</tr>
			<tr>
				<td>Date of Birth</td>
				<td><input type="date" name="dob"></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td><input style="padding-right:20px;"type="radio" name="gender" value="male" checked="checked">Male
				<input type="radio" name="gender" value="female" >female
				</td>


			</tr>
			<tr>
				<td>City</td>
				<td><input type="text" name="city"></td>
			</tr>
			<tr>
				<td>State</td>
				<td><input type="text" name="state"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="pass"> <?php if(isset($_POST['pass']) && strlen($_POST['pass'])<8){ echo '<span style="color:red;text-align:center;">Password must be 8 characters</span>'; }?></td>
			</tr>
			<tr>
				<td> Confirm Password</td>
				<td><input type="password" name="pass2"> <?php if(isset($_POST['pass2']) && strlen($_POST['pass']!=$_POST['pass2'])){ echo '<span style="color:red;text-align:center;">Password must be match also</span>'; }?></td>
			</tr>
					
						<tr>
				<td>Image</td>
				<td><input type="file" name="image" >
			</tr>
			<tr>
				<td>Preferred Languages</td>
				<td> <input type="checkbox" name="la[]" value="Assameese">Assamese
                  <input type="checkbox" name="la[]" value="Bengali" >Bengali
                  <input type="checkbox" name="la[]" value="English" >English<br>
                 <input type="checkbox" name="la[]" value="Gujarati" >Gujrathi
                 <input type="checkbox" name="la[]" value="Hindi" >Hindi
                 <input type="checkbox" name="la[]" value="Marathi" >Marathi
                 <input type="checkbox" name="la[]" value="Urdu" >Urdu
                   <input type="checkbox" name="la[]" value="others" >Others</td>
			</tr>
			<tr>
				<td>Adhar Card Number</td>
				<td><input type="text" name="adh" maxlength="100" width="40px">
				<?php echo '<span style="color:red;text-align:center;">*optional</span>'; ?>
				</td>
			</tr>
			<tr>
				<td>Pan Card Number</td>
				<td><input type="text" name="pan" maxlength="100" width="40px">
				<?php echo '<span style="color:red;text-align:center;">*optional</span>';?></td>
			</tr>
			<tr>
				<td>About Yourself</td>
				<td><input type="text" name="abu" maxlength="100" width="40px"></td>
			</tr>
			
			<tr >
			<td colspan="2" align="center"><button type="submit" name="submit" >Update</button></td>
			</tr>
				
	</table></form>
	<?php } ?>
		
	
			
		
		</div>
		</div>
		
		
	
			<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/stylish-portfolio.js"></script>
    </body>
		<footer>
      <div class="container" id="c">
      
        <div class="row">
          <div class="col-lg-10 mx-auto text-center" >
            <h4>
              <strong >Tourlancer</strong>
            </h4>
            <p >Developed by: <a href="#">Soham Chakrabarti</a> & <a href="#">Soumit sarkar</a></p>
            <ul class="list-unstyled">
              <li>
              Contact us:<br>
                <i class="fa fa-phone fa-fw"  ></i> 
                (+91) 8961177862</li>
                <li>
                <i class="fa fa-phone fa-fw"  ></i>
                (+91) 7044750098</li>
              <li>
               or Mail us at:<br>
                <i class="fa fa-envelope-o fa-fw"></i> 
                <a href="mailto:name@example.com" >soham17041998@gmail.com</a>
              </li>
              <li>
                <i class="fa fa-envelope-o fa-fw"></i>
                <a href="mailto:name@example.com" >soumitcse10@gmail.com</a>
              </li>
            </ul>
            <br>
            <ul class="list-inline">
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-facebook fa-fw fa-3x"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-twitter fa-fw fa-3x"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-dribbble fa-fw fa-3x"></i>
                </a>
              </li>
            </ul>
            <hr class="small">
            <p class="text-muted">Copyright &copy; Tourlancer</p>
          </div>
        </div>
      </div>
      <a id="to-top" href="#top" class="btn btn-dark btn-lg js-scroll-trigger">
        <i class="fa fa-chevron-up fa-fw fa-1x"></i>
      </a>
    </footer>

</html>