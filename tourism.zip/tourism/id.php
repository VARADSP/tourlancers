<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Guide around the world</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #floating-panel {
        position: absolute;
        top: 10px;
        left: 25%;
        z-index: 5;
        background-color: #fff;
        padding: 5px;
        border: 1px solid #999;
        text-align: center;
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
      }
      #floating-panel {
        width: 440px;
      }
      #place-id {
        width: 250px;
      }
        #description {
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
      }

      #infowindow-content .title {
        font-weight: bold;
      }

      #infowindow-content {
        display: none;
      }

      #map #infowindow-content {
        display: inline;
      }

      .pac-card {
        margin: 10px 10px 0 0;
        border-radius: 2px 0 0 2px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        outline: none;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        background-color: #fff;
        font-family: Roboto;
      }

      #pac-container {
        padding-bottom: 12px;
        margin-right: 12px;
      }

      .pac-controls {
        display: inline-block;
        padding: 5px 11px;
      }

      .pac-controls label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }

      #pac-input {
        background-color: #fff;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        margin-left: 12px;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        width: 400px;
      }

      #pac-input:focus {
        border-color: #4d90fe;
      }

      #title {
        color: #fff;
        background-color: #4d90fe;
        font-size: 25px;
        font-weight: 500;
        padding: 6px 12px;
      }
      #target {
        width: 345px;
      }
    </style>
  </head>
  <body >
  <?php    
  $servername="208.91.198.170";
  $username="tourlwg2_root";
  $password="g2]3T2ZAw8";
  $database="tourlwg2_tour";
  $con=mysqli_connect($servername,$username,$password,$database);
  if(isset($_COOKIE["idd"])){
  session_id("prof");
  session_start();
  }
  else {
  	header('Location: index.php');
  }
  $flag=0;
  
          $uid=$_COOKIE["idd"];
          
			
		    $sql_dateChecker= "SELECT * FROM aval WHERE UserId='$uid' ";
		    $result=mysqli_query($con, $sql_dateChecker);
  ?>
   
     <script>
      // Initialize the map.
      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 3,
          center: {lat: 40.72, lng: -73.96}
        });
        var geocoder = new google.maps.Geocoder;
        var infowindow = new google.maps.InfoWindow;


         <?php
        
         while($row1=mysqli_fetch_assoc($result))
		    {
		    	
		    	     $loc=$row1['placeID'];
		    	    
		    		
		    		?>
var placeId ="<?php echo $loc;?>";  
geocodePlaceId(geocoder, map, infowindow, placeId );

        <?php 
}?>
  	

      }</script>
    
      <div id="map"></div>
       
    
   <script type="text/javascript">
      // This function is called when the user clicks the UI button requesting
      // a geocode of a place ID.
      function geocodePlaceId(geocoder, map, infowindow, placeId) {
        //var placeId = document.getElementById('place-id').value;
        
        geocoder.geocode({'placeId': placeId}, function(results, status) {
          if (status === 'OK') {
            if (results[0]) {
              map.setZoom(5);
              map.setCenter(results[0].geometry.location);
              var marker = new google.maps.Marker({
                map: map,
                position: results[0].geometry.location,
                icon: 'http://maps.google.com/mapfiles/ms/icons/hiker.png'
              });
              infowindow.setContent(results[0].formatted_address);
              infowindow.open(map, marker);
              var infowindow = new google.maps.InfoWindow();
              var service = new google.maps.places.PlacesService(map);

              
            }
           else {
              window.alert('No results found');
            }
          } else {
            window.alert('Geocoder failed due to: ' + status);
          }
        });
      }</script>
      
     <div id="infowindow-content">
      <img src="" width="16" height="16" id="place-icon">
      <span id="place-name"  class="title"></span><br>
      <span id="place-address"></span>
    </div>
     
      <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBiJlqWafmoIvGLVAQohVN8gl4zTj6fv-s&callback=initMap">
    </script>
  
   <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBiJlqWafmoIvGLVAQohVN8gl4zTj6fv-s&libraries=places&callback=initMap"
        async defer></script>
    
  </body>
</html>